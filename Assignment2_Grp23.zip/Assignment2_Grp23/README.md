# Advance Database Organisation : Assignment 1 

## Group 23

1. Harshitha Reddy Talusani - A20472820, htalusani@hawk.iit.edu
2. Mounika Gampa - A20488077, mgampa@hawk.iit.edu
3. Venkata Krishna Kapardhi Dendukuri - A20482375, vdendukuri@hawk.iit.edu

 
## Steps to compile and run the assignment

1. Download the assignment folder and change to the respective directory
2. Run make clean command first and then run the file
3. Using make command compile and run the program file which will generate test_assignment_gp23 output
4. You can see output in the terminal

## Functions used in the program

1. initBufferPool

* Here in this function we have created Bufer Pool

2. FIFO(BM_BufferPool *const bm, PgModel *page)

* Here in this function we have written the FIFO function and we are also checking condition in each loop

3. LFU(BM_BufferPool *const bm, PgModel *page)

* Here in this function we have written LFU function and checking each and every loop of the function

4. void LRU(BM_BufferPool *const bm, PgModel *page)

* Here in this function we have written LRU function and checking each and every loop of the function

5. shutdownBufferPool(BM_BufferPool *const bm)

* Here in this function we have written the function to shutdown the buffer pool

6. forceFlushPool(BM_BufferPool *const bm)

* Here in this function we have written the function to flush the buffer pool which causes dirty pages to write disk

7. unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page)

* Here in this function we have written the function to un pin the page

8. pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)

* Here in this function we have written the function to pin page

9. *getFrameContents(BM_BufferPool *const bm)

* Here in this function we have written the function to get the frame contents and checking each and every loop of the function

10. markDirty(BM_BufferPool *const bm, BM_PageHandle *const page)

* Here in this function we have written markDirty function and checking each and every loop of the function

11. *getDirtyFlags(BM_BufferPool *const bm)

* Here in this function we have written getDirtyFlags function to return boolean array and checking each and every loop of the function

12. getNumWriteIO(BM_BufferPool *const bm)

* Here in this function we have written getNumWrite function to return the pages written count

13. getNumReadIO(BM_BufferPool *const bm)

* Here in this function we have written getNumReadIO function to return count for pages read

14. *getFixCounts(BM_BufferPool *const bm)

* Here in this function we have written getFixCount function to return the array
 
15. forcePage(BM_BufferPool *const bm, BM_PageHandle *const page)

* Here in this function we have written forcepage function and checking each and every loop of the function

