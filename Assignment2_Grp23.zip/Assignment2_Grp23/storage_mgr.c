#include "storage_mgr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

FILE *pointerfp;

//Here firstly we have initialized the pointer for the file as null
void initStorageManager(void)
{
    pointerfp = NULL;
    printf("\n *Initializing the storage manager* \n");
}

//Here in this function we have created Page file with size as 1 and page size of 4096 which will return RC_OK else will return RC_FILE_HANDLE_NOT_INIT
RC createPageFile(char *fileName)
{

    printf("\n *creating page file* \n");
    char chrs[PAGE_SIZE];
    pointerfp = NULL;
    pointerfp = fopen(fileName, "w+");
    
    if(fopen(fileName, "w+") == NULL){
        return RC_OK;
    }
    else if (fopen(fileName, "w+") == NULL)
    {
        fclose(fopen(fileName, "w+"));
        printf("\n *function create page file* \n");
        return RC_FILE_HANDLE_NOT_INIT;

    }
    memset(chrs, '\0', sizeof(chrs));
    int psize = 1;
    int fileres = fwrite(chrs, psize, PAGE_SIZE, pointerfp);
    printf("\n *result of fwrite* %d", fileres);
   
    if (PAGE_SIZE != fileres)
    {
        fclose(pointerfp);
        destroyPageFile(fileName);
        printf("\n *returning fhandle not init function* \n");
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else{
        return RC_OK;
    }

    fclose(pointerfp);
    printf("\n *creation successful - RC_OK* \n");
    return RC_OK;
}

//Here based on file pointer and file name this function opens the page file. 
//The function will be successful when the file pointer value is divisible by PAGE_SIZE else we return RC_FILE_NOT_FOUND
RC openPageFile(char *fileName, SM_FileHandle *fHandle)
{
    pointerfp = NULL;
    pointerfp = fopen(fileName, "r+");

    if (fopen(fileName, "r+") == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }
    else if (fopen(fileName, "r+") != NULL)
    {
        fseek(pointerfp, 0, SEEK_END);

        fHandle->fileName = fileName;
        fHandle->curPagePos = 0;

        if (ftell(pointerfp) % PAGE_SIZE != 0)
        {
            fHandle->totalNumPages = (ftell(pointerfp) / PAGE_SIZE + 1);
        }
        else
        {
            fHandle->totalNumPages = (ftell(pointerfp) / PAGE_SIZE);
        }
        fclose(pointerfp);
        printf("\n *Excecuted open page file function* \n");
        return RC_OK;
    }
    printf("\n *Open page file error* \n");
    return RC_FILE_NOT_FOUND;
}

//Here in this function we are returing RC_OK if the file is closed using fclose
RC closePageFile(SM_FileHandle *fHandle)
{
    fHandle->curPagePos = 0;
    fHandle->totalNumPages = 0;
    fHandle->fileName = "";
    return RC_OK;
} 

//Here this function returns RC_OK if it removes the fileName else returns RC_FILE_NOT_FOUND
RC destroyPageFile(char *fileName)
{
    int destroyres = remove(fileName);
    if (destroyres != -1)
    {
        return RC_OK;
    }
    else if (destroyres == -1)
    {
        return RC_FILE_NOT_FOUND;
    }
    printf("\n *Running destroy page file function* \n");
    return RC_OK;
}

//Here by this function we can read the file handle block, mempage and we set the position of the current block to pagenum
//If it is success, the program returns RC_OK otherwise it returns non existing page
RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if (pageNum >= fHandle->totalNumPages){
        return RC_READ_NON_EXISTING_PAGE;
    }
    else if(pageNum < 0){
        return RC_READ_NON_EXISTING_PAGE;
    }
    else
    {
        pointerfp = fopen(fHandle->fileName, "r");
        if (fopen(fHandle->fileName, "r") != NULL)
        {
            int readfseek = fseek(pointerfp, (pageNum * PAGE_SIZE), SEEK_SET);
            printf("\n *fseek :* %d \n", readfseek);
            int readfread = fread(memPage, sizeof(char), PAGE_SIZE, pointerfp);
            printf("\n *fread :* %d \n", readfread);
            fHandle->curPagePos = pageNum;
            fclose(fopen(fHandle->fileName, "r"));
            printf("\n *read block run sucessfully* \n");
            return RC_OK;
        }
        
        printf("\n *Reading readblock function* \n");
        return RC_READ_NON_EXISTING_PAGE;
    }
}

//Here from the respective fhandle page file we are returning the current block position by this function
int getBlockPos(SM_FileHandle *fHandle)
{
    if(fHandle != NULL){
        printf("\n *Current position of block* \n");
        return fHandle->curPagePos;
    }
    else{
        return RC_FILE_NOT_FOUND;
    }
    
}

// Here from the respective fhandle pagefile we can read the first block by this function
RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int readfirstblck=readBlock(0, fHandle, memPage);
    if(readfirstblck == RC_OK){
        printf("\n *Reading first block* \n");
        return readfirstblck;
    }
    else{
        return RC_READ_NON_EXISTING_PAGE;
    }
}

// Here from the respective fhandle pagefile we can read the previous block by this function
RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int currpp = fHandle->curPagePos;
    int currpnum = currpp / PAGE_SIZE;
    int readprevblck=readBlock(currpnum - 1, fHandle, memPage);
    if(readprevblck == RC_OK){
        printf("\n *Reading previous block* \n");
        return readprevblck;
    }
    else{
        return RC_READ_NON_EXISTING_PAGE;
    }
}

// Here from the respective fhandle pagefile we can read the current block by this function
RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int currpp = fHandle->curPagePos;
    int currpnum = currpp / PAGE_SIZE;
    int readcurrblck=readBlock(currpnum, fHandle, memPage);
    if(readcurrblck == RC_OK){
        printf("\n *Reading current block* \n");
        return readcurrblck;
    }
    else{
        return RC_READ_NON_EXISTING_PAGE;
    }
}

// Here from the respective fhandle pagefile we can read the next block by this function
RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int currpp = fHandle->curPagePos;
    int currpnum = currpp / PAGE_SIZE;
    int readnextblck = readBlock(currpnum + 1, fHandle, memPage);
    if(readnextblck == RC_OK){
        printf("\n *Reading next block* \n");
        return readnextblck;
    }
    else{
        return RC_READ_NON_EXISTING_PAGE;
    }
}

// Here from the respective fhandle pagefile we can read the last block by this function
RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int readlstblck = fHandle->totalNumPages - 1;
    if(readlstblck == RC_OK){
        printf("\n *Reading last block* \n");
        return readlstblck;
    }
    else{
        return RC_READ_NON_EXISTING_PAGE;
    }
}

// Here from this function we are writing the block by taking the arguemnts as inputs
// Based on the conditions written below the program runs successful as RC_OK or throws an exception
RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if (ensureCapacity(pageNum, fHandle) == RC_OK)
    {
        FILE *pointerfp;
        pointerfp = fopen(fHandle->fileName, "rb+");
        if (fseek(pointerfp, pageNum * PAGE_SIZE, SEEK_SET) == 0)
        {
            fwrite(memPage, sizeof(char), PAGE_SIZE, pointerfp);
            fHandle->curPagePos = pageNum;
            fclose(pointerfp);
            return RC_OK;
        }
        else
        {    
            return RC_WRITE_FAILED;
        }
    }
    else{

        return RC_FILE_NOT_FOUND;
    }
    return RC_OK;
}

// Here by this function we are writing the current block to file.
RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int pgwriteblck = ((fHandle->curPagePos) / PAGE_SIZE)+1;
    if(writeBlock(pgwriteblck, fHandle, memPage) == RC_OK)
    {
        fHandle->totalNumPages++;
        return RC_OK;
    }
    else{
        return RC_WRITE_FAILED;
    }
    printf("\n  *Writing current block %d* \n", writeBlock(pgwriteblck, fHandle, memPage));
    return RC_OK;
}

// Here by this function we are appending an empty block to file
RC appendEmptyBlock(SM_FileHandle *fHandle)
{
    char *block;
    block = (char *)calloc(PAGE_SIZE, sizeof(char));
    if (fseek(pointerfp, 0, SEEK_END) == 0)
    {
        int pgsize = fwrite(block, sizeof(char), PAGE_SIZE, pointerfp);
        if (pgsize == PAGE_SIZE)
        {
            fHandle->totalNumPages++;
        }       
    }
    else if (fseek(pointerfp, 0, SEEK_END) != 0)
    {
        free(block);
        return RC_WRITE_FAILED;
    }
    free(block);
    fHandle->totalNumPages++;
    printf("\n  *Appending empty block* \n");
    return RC_OK;
}

// Here by this function we check the fHandle capacity to append to empty block
// Based on the below conditions it runs sucessfully or throws an exception
RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle)
{
    
    if(fopen(fHandle->fileName, "a")!= NULL)
    {
        while ((*fHandle).totalNumPages < numberOfPages)
        {
            appendEmptyBlock(fHandle);
        }
    }
    else if (fopen(fHandle->fileName, "a") == NULL)
    {
        fclose(fopen(fHandle->fileName, "a"));
        return RC_WRITE_FAILED;
    }
    if(fopen(fHandle->fileName, "a")!= NULL){
        fclose(fopen(fHandle->fileName, "a"));
    }
    printf("\n*ensure capacity*\n");
    return RC_OK;
}