# Advance Database Organisation : Assignment 3

## Group 23

1. Harshitha Reddy Talusani - A20472820, htalusani@hawk.iit.edu
2. Mounika Gampa - A20488077, mgampa@hawk.iit.edu
3. Venkata Krishna Kapardhi Dendukuri - A20482375, vdendukuri@hawk.iit.edu

 
## Steps to compile and run the assignment

1. Download the assignment folder and change to the respective directory
2. Run make clean command first and then run the file
3. Using make command compile and run the program file which will generate test_assignment_gp23 output
4. You can see output in the terminal

## Functions used in the program

we have added comments on top of each function wwe wrote in the code

