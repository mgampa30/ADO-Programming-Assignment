#include <stdio.h>
#include <stdlib.h>
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include <math.h>

typedef struct Page
{
    SM_PageHandle pghd;
    PageNumber pgno;
    int noclntpg;
    int lru_lusdpg;
    int lfu_lfusdpg;
    int clntmodbit;

} PgModel;
int cft = 0;
int RC_PIN_PAGE_IN_BUFFER_POOL = 16;
int lfu_pgfrpos = 0;
int blen = 0;
int rIndex = 0;
//int RC_ERROR = 15;
int IO_writecnt = 0;



//Here in this function we are creating Bufer Pool
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, const int numPages, ReplacementStrategy strategy, void *stratData)
{
    int j=0;
    int i=0;

    int x= -1;
    blen = numPages;
    bm->numPages = numPages;

    bm->pageFile = (char *)pageFileName;
    bm->strategy = strategy;

    int y=0;
    int z=1;
    

    PgModel *buf_pack = malloc(numPages * sizeof(PgModel));

    if(i==0 && x == -1 && y==0 && z==1)
    {
        for ( j=0;j < blen;j++ )
        {

            buf_pack[j].lfu_lfusdpg = 0;


            buf_pack[j].lru_lusdpg = 0;
            buf_pack[j].pgno = -1;
            buf_pack[j].noclntpg = 0;

            buf_pack[j].clntmodbit = 0;
            buf_pack[j].pghd = NULL;
        }
    }

    else
    {
        return 0;
    }

    bm->mgmtData = buf_pack;

    IO_writecnt = lfu_pgfrpos = 0;

    return RC_OK;
}

//Here in this function we have written the FIFO function and we are also checking condition in each loop
void FIFO(BM_BufferPool *const bm, PgModel *page)
{
    int i=0;
    int j=0;

    int index = rIndex % blen;
    int a=0;
    int b=-1;
    PgModel *pgModel = (PgModel *)bm->mgmtData;

    if(i==0&&a==0&&b==-1)
    {
         for( j=0;blen>j;j++ )
            {
                // printf("iterating a loop to check the condition");

                if(pgModel[index].noclntpg==0 )
                    {
                        // printf("checking for first condition to satisfied");

                        if(1 == pgModel[index].clntmodbit)
                        {
                            // printf("checking for second condition to satisfied");

                            SM_FileHandle f_Handle;
                            openPageFile(bm->pageFile, &f_Handle);
                            writeBlock(pgModel[index].pgno, &f_Handle, pgModel[index].pghd);
                            IO_writecnt += 1;
                            
                        }
                        // printf("checking for first condition  failed to satisfied");

                        pgModel[index].pgno = page->pgno;
                        pgModel[index].pghd = page->pghd;
                        pgModel[index].noclntpg = page->noclntpg;
                        pgModel[index].clntmodbit = page->clntmodbit;
                        break;
                    }
                    // printf("checking for second condition failed to satisfied");
                    else if(pgModel[index].noclntpg != 0)
                    {
                        // printf("incrementing index");

                        index++;
                        if(index % blen == 0)
                        {
                            // printf("assigning it to zero");
                            index=0;
                        }
                        else{
                            // printf("assigning index to index");
                            index=index;
                        }
                            
                    }
                     
                
            }

    }
   
    

}

//Here in this function we have written LFU function and checking each and every loop of the function
void LFU(BM_BufferPool *const bm, PgModel *page)
{

    
    PgModel *pgModel = (PgModel *)bm->mgmtData;
    int x;
    
    int a=0;
    for( a=0;blen>a;a++ )
    {

        if (pgModel[lfu_pgfrpos].noclntpg != 0)
        {
            return;
        }
        else
        {

            goto case1;

            break;
            
        }
        case1:
            x = pgModel[(lfu_pgfrpos + a) % blen].lfu_lfusdpg;
    }

    a = (1 + lfu_pgfrpos) % blen;

        if (pgModel[a].lfu_lfusdpg >= x)
        {
            return;
            
        }
        else
        {
            goto case2;
        }
        case2:
            lfu_pgfrpos = a;
            x = pgModel[a].lfu_lfusdpg;


    SM_FileHandle f_hndl;
    int mainn=1;

    while(pgModel[lfu_pgfrpos].clntmodbit==mainn)
    {
        //  goto case3;
        SM_PageHandle m_pg = pgModel[lfu_pgfrpos].pghd;
        openPageFile(bm->pageFile, &f_hndl);
        writeBlock(pgModel[lfu_pgfrpos].pgno, &f_hndl, m_pg);
        IO_writecnt++;
    }
    // case3:
    //     SM_PageHandle m_pg = pgModel[lfu_pgfrpos].pghd;
    //     openPageFile(bm->pageFile, &f_hndl);
    //     writeBlock(pgModel[lfu_pgfrpos].pgno, &f_hndl, m_pg);


    pgModel[lfu_pgfrpos].noclntpg = page->noclntpg;

    pgModel[lfu_pgfrpos].pgno = page->pgno;
 
    lfu_pgfrpos = 1 + lfu_pgfrpos;

    pgModel[lfu_pgfrpos].pghd = page->pghd;

    pgModel[lfu_pgfrpos].clntmodbit = page->clntmodbit;
}


//Here in this function we have written LRU function and checking each and every loop of the function
void LRU(BM_BufferPool *const bm, PgModel *page)
{
    int x;
    PgModel *pgModel = (PgModel *)bm->mgmtData;
    int a = 0;

    int y;
    // printf("iterating the loop to check the condition");
    for( a=0;a<blen;a++ )
    {
        //  printf("condition satisfied checking other condition");

        if(pgModel[a].noclntpg==0)
        {
            y = a;
            x = pgModel[a].lru_lusdpg;
            
            break;
        }
        //  printf("condition not satisfied checking other condition");

        else if(0 != pgModel[a].noclntpg)
        {
            // printf("continue");
            continue;
        }
    }
    int b = 1 + y;
    // printf("checking the condition");

    while (blen > b)
    {
        //  printf("condition satisfied checking other condition");
        if ( pgModel[b].lru_lusdpg > x )
        {
             b++;
            continue;
            
            
        }
        //  printf("condition not satisfied checking other condition");
        else
        {
            x = pgModel[b].lru_lusdpg;
            y = b;
        }
        b++;
    }

    SM_PageHandle m_pg = pgModel[y].pghd;
    SM_FileHandle f_hndl;
    //  printf("condition  satisfied checking other condition");
    while( pgModel[y].clntmodbit==1 )
    {
        openPageFile(bm->pageFile, &f_hndl);
        writeBlock(pgModel[y].pgno, &f_hndl, m_pg);
        IO_writecnt += 1;
    }

    pgModel[y].pghd = page->pghd;

    pgModel[y].clntmodbit = page->clntmodbit;

    pgModel[y].noclntpg = page->noclntpg;

    pgModel[y].pgno = page->pgno;

   pgModel[y].lru_lusdpg = page->lru_lusdpg;
}


//Here in this function we have written the function to shutdown the buffer pool
RC shutdownBufferPool(BM_BufferPool *const bm)
{
   int sss=0;
   int fff=-1;
    PgModel *pgModel = (PgModel *)bm->mgmtData;
   
    forceFlushPool(bm);
    // printf("iterating the loop to check the condition");
    int i;
    for(i=0;blen>i;i++) 
    {
        // printf("condition satisfied checking other condition");
        if(0==sss)
        {
            if ( pgModel[i].noclntpg == 0 )
            {

                // printf("returning 0");

                return 0;
            }
            else{
                return RC_PIN_PAGE_IN_BUFFER_POOL;
            }
            free(pgModel[i].pghd);
            pgModel[i].pghd = NULL;
        }
        else{

            // printf("returning 0");
            
            return 0;

        }
        
    }

    
    free(pgModel);
    bm->mgmtData = NULL;
    
    return RC_OK;
}


//Here in this function we have written the function to flush the buffer pool which causes dirty pages to write disk
RC forceFlushPool(BM_BufferPool *const bm)
{
    int j=0;
    PgModel *pg_model = (PgModel *)bm->mgmtData;
    while(blen>j)
    {
       

        SM_PageHandle m_pg = pg_model[j].pghd;
        SM_FileHandle f_hndl;
        // printf("trying to check the condition");

        if( pg_model[j].clntmodbit !=1 && pg_model[j].noclntpg != 0 )
        {

            // printf("returning 0");

            return 0;
        }
        else if ( pg_model[j].clntmodbit == 1 && pg_model[j].noclntpg == 0 )
        {

            //  printf("condition satisfied");
            char *f_nm = bm->pageFile;
            pg_model[j].clntmodbit = 0;
            openPageFile(f_nm, &f_hndl);
            writeBlock(pg_model[j].pgno, &f_hndl, m_pg);
            IO_writecnt += 1;
        }

        // printf("incrementing j");

        j++;
    }

   
    return RC_OK;
}


//Here in this function we have written the function to un pin the page
RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page)
{
    PgModel *pg_model = (PgModel *)bm->mgmtData;
    int j= 0;

    if(false)
    {
        // printf("returning 0");

        return 0;
    }
    else{
         while ( j < blen )
        {
            // printf("trying to check the condition");

            if ( pg_model[j].pgno == page->pageNum )
            {
                // printf("condition satisfied");

                pg_model[j].noclntpg -= 1;
                
            }
            // printf("incrementing j");
            j++;
        }
    }
   
    return RC_OK;;
}


//Here in this function we have written the function to pin page
RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
   

    PgModel *pg_model = (PgModel *)bm->mgmtData;
    

    int is_LRU = 1;

    int x=0;

    SM_FileHandle f_hndl;

    int is_LFU = 3;

    if( x==0 )
    {
        // printf("checking for loop iteration");
    }
    else{
        // printf("checking for loop iteration failed");
    }
    if ( pg_model[0].pgno != -1 )
    {
         if(x==0)
        {
        // printf("checking for loop iteration");
        }
        else{
        // printf("checking for loop iteration failed");
        }
        bool temp = true;
        int i;
        for ( i = 0; i < blen; i++ )
        {
             if(x==0)
            {
            // printf("checking for loop iteration");
            }
            else{
            // printf("checking for loop iteration failed");
            }
            if ( pg_model[i].pgno ==  -1 )
            {

                pg_model[i].pghd = (SM_PageHandle)malloc(PAGE_SIZE);

                int z=0;

                pg_model[i].noclntpg = 1;

                int y=-1;

                openPageFile(bm->pageFile, &f_hndl);

                int w=0;

                cft += 1;
                rIndex += 1;

                pg_model[i].lfu_lfusdpg = 0;

                int h=0;

                readBlock(pageNum, &f_hndl, pg_model[i].pghd);

                pg_model[i].pgno = pageNum;

                

                bool s_LRU = ( bm->strategy == 1 ) ? true : false;

                 if(x==0)
                {
                    // printf("checking for loop iteration");
                }
                else{
                    // printf("checking for loop iteration failed");
                }

                if (s_LRU == true)
                {
                    pg_model[i].lru_lusdpg = cft;
                }

                page->data = pg_model[i].pghd;
                if(x==0)
                {
                    // printf("checking for loop iteration");
                }
                else{
                    // printf("checking for loop iteration failed");
                }


                temp = false;


                page->pageNum = pageNum;


                break;
            }
            else
            {
                if ( pg_model[i].pgno != pageNum )
                {
                    temp = true;
                }
                else if ( pg_model[i].pgno == pageNum )
                {

                    bool s_LRU = (bm->strategy == is_LRU) ? true : false;

                    bool s_LFU = false;

                    if(x==0)
                    {
                        // printf("checking for loop iteration");
                    }
                    else{
                        // printf("checking for loop iteration failed");
                     }   
                    if (bm->strategy == 3)
                    {
                        s_LFU = true;
                    }

                    temp = false;
                   

                    pg_model[i].noclntpg++;
                    
                    cft++;

                    if (s_LRU == true)
                    {
                        pg_model[i].lru_lusdpg = cft;
                    }
                  
                    if (s_LFU == true)
                    {
                        pg_model[i].lfu_lfusdpg++;
                    }
                    if(x==0)
                    {
                        // printf("checking for loop iteration");
                    }
                    else{
                        // printf("checking for loop iteration failed");
                     } 
                    page->pageNum = pageNum;

                    page->data = pg_model[i].pghd;
                    if(x==0)
                    {
                        // printf("checking for loop iteration");
                    }
                    else{
                        // printf("checking for loop iteration failed");
                     } 
                    break;
                }
            }
        }

        if (temp)
        {
            PgModel *nPage = (PgModel *)malloc(sizeof(PgModel));
            
            SM_FileHandle f_hndl;

            nPage->pghd = (SM_PageHandle)malloc(PAGE_SIZE);
             if(x==0)
            {   
            // printf("checking for loop iteration");
             }
            else{
                // printf("checking for loop iteration failed");
            } 

            openPageFile(bm->pageFile, &f_hndl);

            nPage->lfu_lfusdpg = 0;
             if(x==0)
            {   
            // printf("checking for loop iteration");
             }
            else{
                // printf("checking for loop iteration failed");
            } 
            readBlock(pageNum, &f_hndl, nPage->pghd);

            rIndex += 1;

            nPage->pgno = pageNum;
          
            nPage->clntmodbit = 0;

          
            cft += 1;
            nPage->noclntpg = 1;

             if( x==0 )
            {   
            // printf("checking for loop iteration");
             }
            else{
                // printf("checking for loop iteration failed");
            } 

            bool s_LRU = ( bm->strategy == is_LRU ) ? true : false;

             if( x == 0 )
            {   
            // printf("checking for loop iteration");
             }
            else{
                // printf("checking for loop iteration failed");
            } 

            if (s_LRU)
            {
                nPage->lru_lusdpg = cft;
            }
            page->data = nPage->pghd;

             if(x==0)
            {   
            // printf("checking for loop iteration");
             }
            else{
                // printf("checking for loop iteration failed");
            } 
            page->pageNum = pageNum;

            if ( bm->strategy == 3 )
            {
                LFU(bm, nPage);
            }

            else if ( bm->strategy == 1 )
            {
                
                LRU(bm, nPage);
            }
            else if ( bm->strategy == 0 )
            {
                FIFO(bm, nPage);
            }
            
        }
        return RC_OK;
    }
    else
    {
        SM_FileHandle f_hdle;
     
        pg_model[0].pghd = (SM_PageHandle)malloc(PAGE_SIZE);
        if(x==0)
        {
            // printf("checking for loop iteration");
        }
        else{
                // printf("checking for loop iteration failed");
        } 
        
        openPageFile(bm->pageFile, &f_hdle);
     

        ensureCapacity(pageNum, &f_hdle);
        if(x==0)
        {
            // printf("checking for loop iteration");
        }
        else{
                // printf("checking for loop iteration failed");
        } 
        readBlock(pageNum, &f_hdle, pg_model[0].pghd);

        pg_model[0].noclntpg++;
 
        pg_model[0].pgno = pageNum;

        rIndex = cft = 0;
      
        pg_model[0].lfu_lfusdpg = 0;
        if(x==0)
        {
            // printf("checking for loop iteration");
        }
        else{
                // printf("checking for loop iteration failed");
        } 
        page->pageNum = pageNum;

        pg_model[0].lru_lusdpg = cft;

        page->data = pg_model[0].pghd;
        if(x==0)
        {
            // printf("checking for loop iteration");
        }
        else{
                // printf("checking for loop iteration failed");
        } 

        return RC_OK;
    }
}

//Here in this function we have written the function to get the frame contents and checking each and every loop of the function
PageNumber *getFrameContents(BM_BufferPool *const bm)
{   
    PageNumber *pg_num = malloc(sizeof(PageNumber) * blen);
    PgModel *pg_model = (PgModel *)bm->mgmtData;
    int j=0;

    int dummyy=-1;
    while( blen > j )
    {
        if ( pg_model[j].pgno == dummyy )
        {
            pg_num[j] = NO_PAGE;
        }
        else
        {
            pg_num[j] = pg_model[j].pgno;
     
        }
        j++;
    }
   
    return pg_num;
}


//Here in this function we have written markDirty function and checking each and every loop of the function
RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page)
{
    PgModel *result_array = (PgModel *)bm->mgmtData;
    
    int j=0;
   
    if(false)
    {
        return 0;
      
    }
    else{
          while ( j<blen )
        {
            if( result_array[j].pgno == page->pageNum )
            {
                result_array[j].clntmodbit = 1;
                return RC_OK;
            }
           j++;
        }
        
    }
    return RC_ERROR;
}


//Here in this function we have written getDirtyFlags function to return boolean array and checking each and every loop of the function
bool *getDirtyFlags(BM_BufferPool *const bm)
{
    
    bool *dirty_flags = malloc(blen * sizeof(bool));


    int j=0;


    PgModel *pg_model = (PgModel *)bm->mgmtData;


    if(false)
    {
        return false;
        
    }
    else{
          while (blen>j)
    {
        // printf("checking for pg_model[j].clntmodbit == 1 if satisfied return true else false");
        if ( pg_model[j].clntmodbit == 1 )
        {
            // printf("returning true");
            dirty_flags[j] = true;
        }
        else
        {
            // printf("returning false");
            dirty_flags[j] = false;
        }
        // printf("incrementing j to plus 1");
        j++;
    }

  
    }
    return dirty_flags;
}


//Here in this function we have written getNumWrite function to return the pages written count
int getNumWriteIO(BM_BufferPool *const bm)
{


    int y=IO_writecnt;



    return y;
}


//Here in this function we have written getNumReadIO function to return count for pages read
int getNumReadIO(BM_BufferPool *const bm)
{



    int x=rIndex + 1;

    return x;
}


//Here in this function we have written getFixCount function to return the array
int *getFixCounts(BM_BufferPool *const bm)
{
    int *client_cnt = malloc(sizeof(int) * blen);
    PgModel *pg_model = (PgModel *)bm->mgmtData;

    int j=0;
    
    int aa=-1;

    if(false)
    {
        return 0;
    }
    else{
        while(blen>j)
        {
            // printf("checking the condition");
            if (pg_model[j].noclntpg == aa)
            {
                // printf("assigning it to zero");

                client_cnt[j] = 0;
            }
            else
            {
                // printf("assigning it to pg_model[j].noclntpg ");


                client_cnt[j] = pg_model[j].noclntpg;
             }
             j++;
        }
    }

    return client_cnt;
}


//Here in this function we have written forcepage function and checking each and every loop of the function
RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page)
{


    PgModel *result_array = (PgModel *)bm->mgmtData;

    int j=0;

    if(false)
    {
        // printf("assigning it to zero");

        return 0;
    }
    else{
        for(j=0;blen>j;j++)
        {
            //  printf(" using goto statement to go through the condition");

            // goto casestudy;
            SM_FileHandle f_handle;
            SM_PageHandle Page_mem = result_array[j].pghd;
            if (result_array[j].pgno == page->pageNum)
            {
                // printf(" using goto statement to go through the condition");

                // goto casestudy1;
                openPageFile(bm->pageFile, &f_handle);
                writeBlock(result_array[j].pgno, &f_handle, Page_mem);
                result_array[j].clntmodbit = 0;
                IO_writecnt++;

            }
        }
    }
    // printf(" goto condition");
    // casestudy:
    //     SM_FileHandle f_handle;
    //     SM_PageHandle Page_mem = result_array[j].pghd;
    //     if (result_array[j].pgno == page->pageNum)
    //     {
    //         // printf(" using goto statement to go through the condition");

    //         // goto casestudy1;
    //         openPageFile(bm->pageFile, &f_handle);
    //         writeBlock(result_array[j].pgno, &f_handle, Page_mem);
    //         result_array[j].clntmodbit = 0;
    //         IO_writecnt++;
            
    //     }

    // printf(" goto condition");
    // casestudy1:
    //         openPageFile(bm->pageFile, &f_handle);
    //         writeBlock(result_array[j].pgno, &f_handle, Page_mem);
    //         result_array[j].clntmodbit = 0;
    //         IO_writecnt++;

    return RC_OK;
}