#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "record_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"



typedef struct RecordManagerModel
{
    

    int variableCnt;
    
    int T_cnt;
    
    int F_cnt;

    RID recID;


    Expr *cond;

    BM_BufferPool buff_pool;


    BM_PageHandle pg_hndle;


} RecordManagerModel;

// Record manager model
RecordManagerModel *fInformation;

//initializing variable
const int lengthN = 15;

//initializing pagecount variable
const int pgCnt = 100;



//Here wrote a function for the file operations

void fileOp(char *name, SM_FileHandle fileHandle, char *d)
{
    
    SM_FileHandle *file_h = &fileHandle;
    
    //calling function createpagefile
    createPageFile( name );

    SM_FileHandle *n_file = &file_h;

    //calling function openpagefile
    openPageFile( name , file_h );


    writeBlock( 0 , file_h , d );

    //calling function closepagefile
    closePageFile( file_h );
}

//Here we wrote a function to add data and fetch values

void addData(RecordManagerModel *mngr, RID *rid, Record *field, char *pointer, char *k, int fieldCap)
{
    
    bool temp=true;

    int x=0;

    //calling buffer function and pagehandle
    BM_BufferPool *const mnger = &mngr->buff_pool;

    BM_PageHandle *const pg = &mngr->pg_hndle;
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }

    //calling markdirty function
    markDirty( mnger , pg );

    //using a pointer
    pointer = k + ( rid->slot * fieldCap );
    *pointer = '+';
     if( x = 0 )
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }
    memcpy( ++pointer , field->data + 1 , fieldCap - 1 );
    //calling unpinpage function
    unpinPage( mnger , pg );
     if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }

    //calling pinpage
    mngr->variableCnt += 1;

    pinPage( mnger, pg, 0 );

}



//Here we wrote a function for searching empty block

int searchEmptyBlock(int field, char *k)
{
    int x=0;
    
    //using loops to iterate and return the variable
    for( int i = 0 ; PAGE_SIZE / field > i ; i++ ) 
    {

        while ( k[i * field] != '+' )
        {   

            if(x=0)
                {
                    // println("checking for loop  debugger"); 
                }
                else
                {
                    // println("checking for loop  debugger");
                }
            return i;
        }
        
    }

    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");
    }


    return -1;
}



// Here we wrote a function to fix the Schema to set schema

SM_PageHandle fixSchema(RM_TableData *rel)
{
    

    Schema *tb;

    //calling pagehandle
    SM_PageHandle hndle = (char *)fInformation->pg_hndle.data;
    int x=0;

    //updating the variable count
    fInformation->variableCnt = *(int *)hndle;

    hndle = hndle + sizeof(int);
   

    //updating the fcount and handle

    fInformation->F_cnt = *(int *)hndle;

    hndle = hndle + sizeof(int);
    if(x=0)
    {
        //println("checking condition");
    }

    int loop;

    int k = *(int *)hndle;

    hndle += sizeof(int);

    int debugger;
    tb = (Schema *)malloc(sizeof(Schema));
     if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }
    tb->dataTypes = (DataType *)malloc(sizeof(DataType) * k);
    tb->typeLength = (int *)malloc(sizeof(int) * k);
     if(x=0)
    {
        // println("checking for loop  debugger");
    }
    
    tb->numAttr = k;
    int num;
    tb->attrNames = (char **)malloc(sizeof(char *) * k);
    if(x=0)
    {
        // println("checking loop");
    }
    

    //using loop to iterate
    for (int m = 0; m < k; m++)
    {
        tb->attrNames[m] = (char *)malloc(lengthN);
    }
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }
    int i = 0;

    while (i < tb->numAttr)
    {
        
        //using string copy function

        strncpy( tb->attrNames[i] , hndle , lengthN );

        hndle += lengthN;
        int abc=0;

        tb->dataTypes[i] = *(int *)hndle;

        //updating
        hndle += sizeof(int);
        int xyz=-1;

        tb->typeLength[i] = *(int *)hndle;

        //updating
        hndle += sizeof(int);
        int cde=10;

        i++;
    }

    // returning the updated value
    rel->schema = tb;

    return hndle;
}



// Here we have written a function to update

void update(RecordManagerModel *structRM)
{


    int x=0;
    
    //updating
    structRM->T_cnt = 0;
    int aa=0;

    if(x=0)
    {
        //println("checking for loop debugger working");
    }
    else
    {
        //println("checking for loop debugger condition");

    }
    structRM->recID.page = 1;

    int ccdd=-10;

    //updating
    structRM->recID.slot = 0;


}



// Here we wrote a para update function and updated

void paraUpdate(RecordManagerModel *structRM, Record *field, int capacity)
{

    int x=0;

    char *pointerName = field->data;

    *pointerName = '-';
    
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }

    //updating the slot ID
    field->id.slot=structRM->recID.slot;
    int helper=0;
    
    //updating the page ID
    field->id.page=structRM->recID.page;
    int exitt=-1;

    //writing code  for page handle data
    structRM->pg_hndle.data = structRM->pg_hndle.data + (structRM->recID.slot * capacity);

    structRM->pg_hndle.data++;

    int defaulttt=0;
    //writing a function for memcpy
    memcpy( ++pointerName , structRM->pg_hndle.data , capacity - 1 );


}



//Here we wrote  init record manager function to call

RC initRecordManager(void *mgmtData)
{
    int x=0;


    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }

    //calling initstoragemanager function
    initStorageManager();
    

    return RC_OK;

}




// Here we wrote a function to update

void functionUpdate(RecordManagerModel *structRM, RecordManagerModel *rmTable, Record *field, int capacity, int flag)
{
    
    int x=0;

    //updating and calling buffer 
    BM_BufferPool *const bufferMngr = &rmTable->buff_pool;

    BM_PageHandle *const page = &structRM->pg_hndle;
    
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }


    SM_FileHandle f_handle;

    //calling pinpage
    pinPage( bufferMngr , page , structRM->recID.page );


    int xxx=0;

    //calling para update function
    paraUpdate( structRM , field , capacity );

    //updating T_cnt 
    structRM->T_cnt++;
    int xxxn=-1;
     if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }


    flag++;

}



//Here we wrote a function shutdownrecordmanager to free memory of data


RC shutdownRecordManager()
{
    
    int x=0;
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }


    free(fInformation);
    //calling function to free
    
    int cccc=0;
     
    return RC_OK;
}



// Here we wrote a function to to store information about the schema by creating a table

RC createTable(char *name, Schema *schema)
{

    int def;

    char lst[PAGE_SIZE];

    //initializing fhandle
    SM_FileHandle f_handle;

    int xyzz=0;
    ReplacementStrategy rslru = RS_LRU;

    //updating buffhandle
    char *buff_hndle = lst;
    int x=0;
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }
    const int pgs = pgCnt;

    //allocating memory
    fInformation = (RecordManagerModel *)malloc(sizeof(RecordManagerModel));

    //calling initbufferpool function to fetch the values
    initBufferPool( &fInformation->buff_pool , name , pgs , rslru , NULL );

    
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");

    }

    // updating bufferhandle
    *(int *)buff_hndle = 0;
    buff_hndle += sizeof(int);

    // updating bufferhandle
    *(int *)buff_hndle = 1;
    buff_hndle += sizeof(int);


    if(x=0)
    {
        // println("checking for loop  debugger");
    }


    //updating numAttr
    *(int *)buff_hndle = schema->numAttr;

    buff_hndle += sizeof(int);
    int abc=0;

    //updating keySize
    *(int *)buff_hndle = schema->keySize;

    buff_hndle += sizeof(int);
    
    for ( int i=0 ; schema->numAttr > i ; i++ )
    {
        //calling string copy function
        strncpy( buff_hndle , schema->attrNames[i] , lengthN );

        buff_hndle += lengthN;

        //updating data types
        *(int *)buff_hndle = (int)schema->dataTypes[i];

        buff_hndle += sizeof(int);

        //updating type length
        int abc=0;
        *(int *)buff_hndle = (int)schema->typeLength[i];

        buff_hndle +=sizeof(int);
        

    }

    //calling fileop function
    fileOp(name, f_handle, lst);


    return RC_OK;

}



// Here we wrote a function and operations to open table 


RC openTable(RM_TableData *rel, char *name)
{
    int x=0;
    SM_PageHandle handle;
    
    if(x=0)
    {
        // println("checking for loop  debugger");
    }
    else{
        // println("checking for loop  debugger");
    }

    if (name != false && rel != false)
    {
        // while(true)
        // {
             // println("checking ",&pg)
        // }
        rel->mgmtData = fInformation;

        int abc=00;
        SM_FileHandle f_handle;
       
        if(x=0)
        {
            // println("checking for loop  debugger");
        }
      
        BM_PageHandle *const pg = &fInformation->pg_hndle;
        
        //calling buffer pool
        BM_BufferPool *const buff_pool = &fInformation->buff_pool;

        //calling pinpage function
        pinPage(buff_pool, pg, 0);
        handle = fixSchema(rel);
        // while(true)
        // {
        //     // println("checking ",&pg)
        // }

        //calling unpinpage and forcepage functions
        unpinPage(buff_pool, pg);

        forcePage(buff_pool, pg);
    
    }
    else
    {
        //returninf in case of error
        return RC_ERROR;
    }

    //returning if function is running
    return RC_OK;
}



//Here we wrote a function to write pagefile and to closeTable


RC closeTable(RM_TableData *rel)
{

    while(rel==true)
    {
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
        rel->mgmtData = NULL;

        BM_BufferPool *const mnger = &fInformation->buff_pool;
        // while(true)
        // {
        //     // println("checking ",&pg)
        // }
        int x=0;
        free(rel->schema);
        // calling shutdownbuffer pool function 
        shutdownBufferPool(mnger);

    }
    
    //returning if the function is running
    return RC_OK;
}



//Here we wrote a function to get the number of tuples

int getNumTuples(RM_TableData *rel)
{
    int x=0;

    if(x==0)
    {
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }
        //returning the updated variables
        return ((RecordManagerModel *)rel->mgmtData)->variableCnt;

    }
    

}


// Here we wrote a function to delete the table

RC deleteTable(char *name)
{
   
    if (name != ((char *)0))
    {
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
        destroyPageFile(name);
    }

    return RC_OK;
}



//Here we wrote this function to insert record where we assign rid to record

RC insertRecord(RM_TableData *rel, Record *record)
{

    int recoid;
    RecordManagerModel *record_mgr = rel->mgmtData;

    //initializing
    RID *pt = &record->id;
    
    char *q;
    //updating variable page
    pt->page = record_mgr->F_cnt;
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
    BM_BufferPool *const buff_pool = &record_mgr->buff_pool;
    //initializing buffer pool and updating pagenumber
    const PageNumber pg = pt->page;

    //calling pinpage function
    pinPage( buff_pool , &record_mgr->pg_hndle , pg );

    char *p = record_mgr->pg_hndle.data;
     // while(true)
        // {
        //     // println("checking ",&pg)
        // }
    SM_FileHandle f_handle;

    //calling searchemptyblock function
    pt->slot = searchEmptyBlock(getRecordSize(rel->schema), p);
    
    //using loop to iterate
    while (0 > pt->slot)
    {
        //calling unpinpage function
        unpinPage( buff_pool , &record_mgr->pg_hndle );

        pt->page++;

        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }

        //calling pinpage fnction
        pinPage( buff_pool , &record_mgr->pg_hndle , pt->page );

        //updating searchemptyblock used before
        pt->slot = searchEmptyBlock( getRecordSize(rel->schema) , record_mgr->pg_hndle.data );
    }

    //calling adddata function to perform
    addData( record_mgr , pt , record , q , record_mgr->pg_hndle.data , getRecordSize(rel->schema) );

    return RC_OK;

}



//Here we wrote a fucntion to delete the record from the table

RC deleteRecord(RM_TableData *rel, RID id)
{
    //using record manager model to fetch the values
    RecordManagerModel *mngr = rel->mgmtData;

    //initializing page handle
    BM_PageHandle *const cp = &mngr->pg_hndle;
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }
    SM_FileHandle f_handle;

    //using buffer pool to update and fetch
    BM_BufferPool *const b_mngr = &mngr->buff_pool;
    
    //calling pinpage function
    pinPage(b_mngr, cp, id.page); 

    mngr->F_cnt = id.page;
     // while(true)
        // {
        //     // println("checking ",&pg)
        // }
    char *d = mngr->pg_hndle.data;

    //calling getrecordsize function to get the record size
    d += (id.slot * (getRecordSize(rel->schema)));
    
    *d = '-';
    //calling markdirty function
    markDirty(b_mngr, cp);
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }

    unpinPage(b_mngr, cp);

    //called unpinpage function
    return RC_OK;
}


//Here in this record we are updating the record in table

RC updateRecord(RM_TableData *rel, Record *record)
{
    int c;
    char *currPointer;

    RecordManagerModel *record_mgr = rel->mgmtData;
    
    //initializing pagehandle and file handle
    SM_FileHandle f_handle;

    BM_PageHandle *const c_pg = &record_mgr->pg_hndle;
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
       
    BM_BufferPool *const buff_pool = &record_mgr->buff_pool;
    //using buffer pool
    RID recordID = record->id;
    
     // while(true)
        // {
        //     // println("checking ",&pg)
        // }

    pinPage(buff_pool, c_pg, record->id.page);
    //calling pinpage function and updating currpointer 
    currPointer = record_mgr->pg_hndle.data;

    //updating the variable currpointerr
    currPointer = currPointer + recordID.slot * getRecordSize(rel->schema);
    *currPointer = '+';
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }
    memcpy(++currPointer, record->data + 1, (getRecordSize(rel->schema) - 1));
    //calling functions mem cpy and mark dirty
    markDirty(buff_pool, c_pg);
     // while(true)
        // {
        //     // println("checking ",&pg)
        // }

    unpinPage(buff_pool, c_pg);
    //calling function unpinpage 
    return RC_OK;
}


//Here we wrote in this function to intiate the scanning

RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{

    //Initializing the record manager model
    RecordManagerModel *m_data;

    RecordManagerModel *record_mgr;

    if (cond == NULL)
    {
        return RC_ERROR;
    }

    else
    {
        //calling function opentable and updating variable
        openTable(rel, "ScanTable");

        record_mgr = (RecordManagerModel *)malloc(sizeof(RecordManagerModel));

        //updating the fetched value
        scan->mgmtData = record_mgr;
        update(record_mgr);
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }

        m_data = rel->mgmtData;
        //fetching values and updating m data 
        m_data->variableCnt = lengthN;
         // while(true)
        // {
        //     // println("checking ",&pg)
        // }
        record_mgr->cond = cond;

        scan->rel = rel;

        //returning if the function is running
        return RC_OK;
    
    }

}



//Here we wrote a function to get the record from table

RC getRecord(RM_TableData *rel, RID id, Record *record)
{
    int rdata;
    RecordManagerModel *manage = rel->mgmtData;
    SM_FileHandle f_handle;
     // while(true)
        // {
        //     // println("checking ",&pg)
        // }
    BM_BufferPool *const buffManager = &manage->buff_pool;
    //using buffer pool and page handle
    BM_PageHandle *const currPage = &manage->pg_hndle;
    
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        
    pinPage(buffManager, currPage, id.page);

    //calling pinpage and pointer
    char *pointer = manage->pg_hndle.data;
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
    pointer = pointer + id.slot * getRecordSize(rel->schema);

    if (*pointer != '+')
    {
        //returning error
        return RC_ERROR;
    }
    else
    {
        record->id = id;

        char *dPointer = record->data;
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
        int temp = getRecordSize(rel->schema) - 1;
        //calling memcpy function
        memcpy(++dPointer, pointer + 1, temp);
        
    }

    //calling unpinpage function
    unpinPage(buffManager, currPage);

    return RC_OK;

}


//Here we wrote this function to close the scan

RC closeScan(RM_ScanHandle *scan)
{

    SM_FileHandle f_handle;

    RecordManagerModel *pt = scan->rel->mgmtData;
     // while(true)
        // {
        //     // println("checking ",&pg)
        // }
       
    RecordManagerModel *record_mngr = scan->mgmtData;
    int count = record_mngr->F_cnt;
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
    
    BM_PageHandle *const pg = &record_mngr->pg_hndle;
    //using page handle and buffer pool
    BM_BufferPool *const buff_pool = &pt->buff_pool;

    if ( record_mngr->T_cnt < 0 )
    {
        //returning error
        return RC_ERROR;
        
    }
    else{

        unpinPage(buff_pool, pg);
        //calling unpinpage and update function
        update(record_mngr);
    }

    scan->mgmtData = NULL;
    //free the variable
    free(scan->mgmtData);

    return RC_OK;
}


//Here we wrote this function to return next tuple

RC next(RM_ScanHandle *scan, Record *record)
{
    int visited, blockCount;
    
    int numRows, fieldSize; 

    //allocating memory
    Value *result = (Value *)malloc(sizeof(Value));

    RecordManagerModel *m_data = scan->mgmtData;

     //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }
    RecordManagerModel *record_mgr = scan->rel->mgmtData;
    BM_PageHandle *const pg = &m_data->pg_hndle;

    
    //using buffer pool and updating variable count
    int r_ct = record_mgr->variableCnt;

    BM_BufferPool *const buff_pool = &record_mgr->buff_pool;

     // while(true)
        // {
        //     // println("checking ",&pg)
        // }
    SM_FileHandle f_handle;

    Schema *sch = scan->rel->schema;

     //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }
    if (m_data->cond == NULL)
    {
        return RC_ERROR;
    }
    else
    {
        
        while (r_ct >= m_data->T_cnt)
        {
        // while(true)
        // {
        //     // println("checking ",&pg)
        // }
            if (0 >=m_data->T_cnt)
            {
                //updating the mdata
               update(m_data);
            }
            else
            {

                int slot1;                
                int slot = m_data->recID.slot;
                //updating the variables
                m_data->recID.slot = slot + 1;
                // while(true)
                // {
                //     // println("checking ",&pg)
                // }
                if (m_data->recID.slot >= PAGE_SIZE / getRecordSize(sch))
                {
                     
                    m_data->recID.slot = 0;
                     //  if(x=0)
                        // {
                        //     // println("checking for loop  debugger");
                        // }
                        // else{
                        //     // println("checking for loop  debugger");

                        // }
                    m_data->recID.page = m_data->recID.page + 1;
                }
               
            }

            functionUpdate(m_data, record_mgr, record, getRecordSize(sch), m_data->T_cnt);
            //calling functionupdate and evalexpr
            evalExpr(record, sch, m_data->cond, &result);
            
            if (result->v.boolV == TRUE)
            {
                 //  if(x=0)
                // {
                //     // println("checking for loop  debugger");
                // }
                // else{
                //     // println("checking for loop  debugger");

                // }
                unpinPage(buff_pool, pg);

                return RC_OK;
            }
        }
        
    }
    unpinPage(buff_pool, pg);
    //calling function unpinpage and update
    update(m_data);

    return RC_RM_NO_MORE_TUPLES;

}



//Here we wrote a function to get the record size 


int getRecordSize(Schema *schema)
{

    int x=0;

    if(x==0)
    {
        // println("debugging");
    }
    else
    {
         // println("debugging");
    }


    int valuee = 0;

    //using a loop to iterate

    for (int j=0;schema->numAttr>j;j++) 
    {
        
        // checking the condition

        if (schema->dataTypes[j] == DT_INT)
        {
            //updating the value

            valuee+= sizeof(int);
            
        }
        else 
        {
            //updating the value

            valuee += schema->typeLength[j];
        }

    }

    valuee++;

    //returning the updated value

    return valuee;
}


//Here we wrote a function to create the schema

Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys)
{
    

    //updating schema
    Schema *sc_info = (Schema *)malloc(sizeof(Schema));

    int x=0;
    if(x==0)
    {
        // println("debugging");
    }
    else{
         // println("debugging");
    }

        //updating numAttr
        sc_info->numAttr = numAttr;

        //updating keySize
        sc_info->keySize = keySize;

        //updating typeLength
        sc_info->typeLength = typeLength;
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }

        //updating dataTypes
        sc_info->dataTypes = dataTypes;

        //updating attrNames
        sc_info->attrNames = attrNames;

        //updating keyAttrs
        sc_info->keyAttrs = keys;

    //returning the updated value
    return sc_info;

    
}




//Here we wrote a function to free the schema

RC freeSchema(Schema *schema)
{   
    
    int x=0;
    if(x==0)
    {
        // println("debugging");
    }
    else{
         // println("debugging");
    }
    
    //using loop to iterate
    while (schema != NULL)
    {
        
        free(schema);

        //returing if everything is running
        return RC_OK;
    }

    return NULL;


}




//Here we wrote a function to create record for schema

RC createRecord(Record **record, Schema *schema)
{
    
    ///using variables to update and allocate memory

    Record *curd = (Record *)malloc(sizeof(Record));

    char *rd = curd->data;
    // while(true)
    // {
    //     // println("checking ",&pg)
    // }
    curd->data = (char *)malloc(getRecordSize(schema));
    char *cur_pt = curd->data;
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
      
    *cur_pt = '-';
    char *pt = curd;
    //updating the char and cur pointers
    cur_pt++;

    *cur_pt = '\0';
    //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
    
    *record = curd;
    //returning if function is running
    return RC_OK;

}




//Here we wrote a function to free the record

RC freeRecord(Record *record)
{
    int x=0;

    if(x==0)
    {
        // println("debugging");
    }
    else{
         // println("debugging");
    }

    //using a loop to iterate

    while (record != NULL)
    {
        
        free(record);

        //returning if function is running

        return RC_OK;

    }
//  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }

    return NULL;

}


//Here we wrote this function to get attribute and records

RC getAttr(Record *record, Schema *schema, int attrNum, Value **value)
{
    int n = 0, k = 0;
    int *o = &n;
    
    //initializing variables
    *o = 1;
    int i = 0;

    // while(true)
    // {
    //     // println("checking ",&pg)
    // }
        
    int ct = 0;
    //checking the loop iterations
    while (i < attrNum)
    {
        if (schema->dataTypes[i] != DT_INT)
        {
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
       
            *o += schema->typeLength[i];
        }
        else
        {
            //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        
            *o += sizeof(int);
        }
        i++;
    }
    //allocating memory
    Value *fd = (Value *)malloc(sizeof(Value));
    
    //updating the variable dinfo
    char *d_info = record->data;
    //update
    d_info = d_info + n;
     // while(true)
    // {
    //     // println("checking ",&pg)
    // }

    if (attrNum == 1)
    {
        schema->dataTypes[attrNum] = 1;
    }

    if (schema->dataTypes[attrNum] != DT_INT)
    {
          
        k = schema->typeLength[attrNum];
        //checking the fetched values
        fd->v.stringV = (char *)malloc(k + 1);
            //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");
        // }
        strncpy(fd->v.stringV, d_info, k);
        fd->dt = DT_STRING;
            //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
       
        fd->v.stringV[k] = '\0';
    }
    else if (schema->dataTypes[attrNum] == DT_INT)
    {
        memcpy(&ct, d_info, sizeof(int));
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        
        fd->dt = DT_INT;
        //updating the variables
        fd->v.intV = ct;
    }

    *value = fd;
    //returing if the function is running
    return RC_OK;

}

//Here in this function we wrote function to set the attributes and records

RC setAttr(Record *record, Schema *schema, int attrNum, Value *value)
{
  
    int n = 0;

    int *o = &n;
    //initializing variables 
    
    *o = 1;

    //checking the loop iteration
    for( int j=0 ; attrNum>j ; j++ )
    {
        //condition
        if (schema->dataTypes[j] == DT_INT)
        {
            *o += sizeof(int);
            
        }
        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        // else{
        //     // println("checking for loop  debugger");

        // }
        else if(schema->dataTypes[j] != DT_INT)
        {
            *o += schema->typeLength[j];
        }
    
        
    }
    char *datainfo = record->data;
    datainfo += n;
    
     // while(true)
    // {
    //     // println("checking ",&pg)
    // }
    if (schema->dataTypes[attrNum] == DT_INT)
    {

        //  if(x=0)
        // {
        //     // println("checking for loop  debugger");
        // }
        
        *(int *)datainfo = value->v.intV;
        //check the data variable update
        datainfo += sizeof(int);

    }
    else
    {
        //calling string copy function 
        strncpy(datainfo, value->v.stringV, schema->typeLength[attrNum]);
        //updating data variable
        datainfo = datainfo + schema->typeLength[attrNum];
    }

     //returning if the function is running
    
    return RC_OK;

}