       
import pandas as pd
import time
from collections import OrderedDict
import re
import sys


if len(sys.argv)!=3:
    print('ERROR: Not enough or too many input arguments.')
    exit(0)
else:
          
    Start=str(sys.argv[1])
    End=str(sys.argv[2])
    
    straightline = pd.read_csv('straightline.csv', header=0, index_col=0, squeeze=True).to_dict()
    driving = pd.read_csv('driving.csv', header=0, index_col=0, squeeze=True).to_dict()
    


    
    
    print('')
    print('Mounika, Gampa ,A20488077 , Solution:')
    print('Initial State : %s ' % Start)
    print('Goal State : %s ' % End)
    print('')
    
    if Start not in straightline.keys() or End not in straightline.keys():
        
        print('CITY DOES NOT EXIST.')
        print('Solution path: FAILURE: NO PATH FOUND')
        print('Number of states on a path: 0')
        print('Path cost: 0')
        exit(0)
        
    else:
    
        start_time_T3 = time.perf_counter()
        List_s=[]
        for k in driving[Start]:
            if driving[Start][k]>0:
                List_s.append([k,driving[Start][k]])
        List_e=[]
        for k in driving[End]:
            if driving[Start][k]>0:
                List_e.append([k,driving[Start][k]])
        if len(List_s)==0 or len(List_e)==0:
            end_time_T3 = time.perf_counter()    
    
            print('Solution path: FAILURE: NO PATH FOUND')
            print('Number of states on a path: 0')
            print('Path cost: 0')
            print('Execution time : %g' % (end_time_T3 - start_time_T3) )
            exit(0)
            
        if Start==End:
             print('Initial and Goal is same state')
        else:
          
            def GBFS(Start,End):
                
                Path=[Start]
                Path_cost=[]
                node=Start
                
                while Path:
                #    print(Start)                    
                    Graph=[]
                    for k in driving[node]:
                        if driving[node][k]>0:
                            Graph.append([k,driving[node][k]])
                            
                    neighbours=[]   
                    for k in range(len(Graph)):
                        neighbours.append([Graph[k][0],Graph[k][1],straightline[End][Graph[k][0]]])
                        
                        
                    neighbours = sorted(neighbours, key=lambda x:x[2])
                #    print(neighbours)
                
                    
                    node=neighbours[0][0]
                    Dist=neighbours[0][1]
                    
                    Path.append(node)
                    Path_cost.append(Dist)
                    
                    if node==End:
                        len_Path=len(Path)
                        break
                    
                    if len(Path)>len(straightline.keys()):
                        
                        Path=['FAILURE: NO PATH FOUND']
                        len_Path=0
                        Path_cost=0
                        break
                    
                return Path,Path_cost,len_Path
            
            
            start_time_T1 = time.perf_counter()
            (Path,Path_cost,len_Path)=GBFS(Start,End)
            end_time_T1 = time.perf_counter()
            
            print('Gready Best First Search:')
            separator = ", "  
            print('Solution path : %s' % separator.join(Path))
            print('Number of states on a path: %s' % len_Path)
            print('Path cost : %s ' % sum(Path_cost)) 
            print('Execution time : %g' % (end_time_T1 - start_time_T1) )
            
            
            def a_star(Start,End):
                
                def remove_digit(input_):
                    res = ''.join([i for i in input_ if not i.isdigit()])
                    return res
                
                def Convert(tup, di):
                    di = dict(tup)
                    return di
                
                  
                def remove(list):
                    pattern = '[0-9]'
                    list = [re.sub(pattern, '', i) for i in list]
                    return list
                
                
                def Path_cost(Path):
                    Path_cost=0
                    for i in range(len(Path)-1):
            #             print(driving[Path[i]][Path[i+1]])
                         Path_cost=Path_cost+driving[Path[i]][Path[i+1]]
                    return Path_cost
                        
                
                #A*
                Path=[]
                path_all={}
                path_all[Start]=[Start]
                node=Start
                opened_node=[Start]
                
                
                Graph1={}
                for keys in driving:
                    Graph1[keys]={}
                    for keys1 in driving[keys]:
                #        print(driving[keys][keys1])
                        if driving[keys][keys1]>0:
                            Graph1[keys][keys1]=driving[keys][keys1]
                        
                        
                straight_line=straightline[End]
                
                f_list={}
                
                while Start:
                #    print(i)
                    f={}
                    Path=path_all[node]
                    h=0
                    for j in range(len(Path)-1):
                        h=h+Graph1[remove_digit(Path[j])][remove_digit(Path[j+1])]
                
                    neigbors=Graph1[remove_digit(node)]
                
                    for key in neigbors.keys():
                #        print(key)
                        if key in path_all.keys():
                            key=key+'1'
                #            print("Key exists")  
                        else:
                            key=key
                                
                        f[key]=h+neigbors[remove_digit(key)]+straight_line[remove_digit(key)]
                
                        path_all[key]=path_all[node]+[key]
                        
                    f_list.update(f)
                    f_test= (sorted(f_list.items(), key=lambda x: x[1])  )
                    f_list = OrderedDict(f_test)
                #    print('stop')
                    
                
                    if node==Start:
                        node
                    else:
                        del(f_list[node])
                
                
                    node=next(iter(f_list))
                    opened_node.append(node)
                
                
                            
                    if remove_digit(node)==End:
                       break
                   
                    if len(Path)>len(straightline.keys()):
                        
                        Path=['FAILURE: NO PATH FOUND']
                        len_Path=0
                        Path_cost=0
                        break
                    
                Path=path_all[node]
                
                
                Path=remove(Path)
                Path_cost=Path_cost(Path)
                                       
                len_Path=len(Path)

                return Path,Path_cost,len_Path
            
            print('')
            print('A* Search:')
            start_time_T2 = time.perf_counter()
            (Path,Path_cost,len_Path)=a_star(Start,End)  
            end_time_T2 = time.perf_counter() 
            separator = ", "  
            print('Solution path : %s' % separator.join(Path))
            print('Number of states on a path: %s' % len_Path)
            print('Path cost : %s ' % (Path_cost)) 
            print('Execution time : %g' % (end_time_T2 - start_time_T2) )




